package Gui;

import database.Koneksi;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.table.DefaultTableModel;

//overloading
    public class Menuadmintambahdata extends javax.swing.JFrame {
        Connection conn=null;
        ResultSet rs=null;
        PreparedStatement pst=null;
        int curRow=0;
    private void teks(){
        isi_id.setText("");
        isi_merk.setText("");
        isi_warna.setText("");    
        isi_qty.setText("");
    }
//Override
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Menuadmintambahdata().setVisible(true);
            }
        });
    }
    
    public Menuadmintambahdata(){
        initComponents();
           conn=Koneksi.connect();
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        setLocation(
        (screenSize.width - frameSize.width) / 2,
        (screenSize.height - frameSize.height) / 2);
        tabel();
        tampilkandata();
    }
    
    // overloading menampilkan fungsi yg sama dengan parameter yg berbeda
    public void Tambahdatamobil(){
       
        try {
           
           PreparedStatement stmt = conn.prepareStatement("INSERT INTO listmobil (Id_mobil, Merk,  Warna, harga, QTY, id) values (?,?,?,?,?,?)");
            stmt.setString(1, isi_id.getText());
            stmt.setString(2, isi_merk.getText());
            stmt.setString(3,isi_warna.getText());
            stmt.setString(4, isi_harga.getText());
            stmt.setString(5, isi_qty.getText());
            stmt.setString(6, (String) isi_idpelanggan.getSelectedItem());
       
       
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data berhasil disimpan", "Pesan", JOptionPane.INFORMATION_MESSAGE);
            tampilkandata();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal Menambahkan" + e.getMessage());

        }
    }         
  //overloading  
    public void tampilkandata(){
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Id Mobil");
        model.addColumn("Merk Mobil");
        model.addColumn("Warna");
        model.addColumn("Harga");
        model.addColumn("QTY");
        model.addColumn("Id Pelanggan");
        try{
            int no = 1;
            String sql = "SELECT * From listmobil";
            java.sql.Connection con = (Connection) Koneksi.connect();
            java.sql.Statement stmt = con.createStatement();
            java.sql.ResultSet res = stmt.executeQuery(sql);
            
            while(res.next()){
                String[] data = {res.getString(1),res.getString(2),res.getString(3),res.getString(4),res.getString(5),res.getString(6)}; // eksekusi query
             model.addRow(data);
//                model.addRow(new Object[]{ res.getString(0),res.getString(1), res.getString(2), res.getString(3), res.getString(4)});
            }
            tabelmobil.setModel(model);
    }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    
    
     public void tabel(){
        DefaultTableModel tbl = new DefaultTableModel();
      
          tbl.addColumn("kode jurusan");
         tbl.addColumn("tingkat");
        tbl.addColumn("jurusan");
         tbl.getDataVector().removeAllElements();
        tbl.fireTableDataChanged();
        try {
            String sql = "SELECT * FROM listmobil";
            Connection con = (Connection) Koneksi.connect();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                tbl.addRow(new Object[] {
                 
                      rs.getString("id"),

                });
                
            
              isi_idpelanggan.addItem(rs.getString("id"));
                
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
            public void perbaruidata(){
        try{
            String sql = "UPDATE `listmobil` SET `Id_mobil`='"+isi_id.getText()+"',`Merk`='"+isi_merk.getText()+"',"+ "`Warna`='"+isi_warna.getText()+"',`Harga`='"+isi_qty.getText()+"' WHERE Id_mobil="+isi_id.getText();
            java.sql.Connection con = (Connection) Koneksi.connect();
            java.sql.Statement stmt = con.createStatement();
            java.sql.PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.execute();   
            JOptionPane.showMessageDialog(null, "Data Mobil Berhasil Diubah!");     
        }    
            catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }     
        tampilkandata();
    
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        isi_id = new javax.swing.JTextField();
        isi_merk = new javax.swing.JTextField();
        isi_qty = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelmobil = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        isi_warna = new javax.swing.JTextField();
        bttambah = new javax.swing.JButton();
        bthapus = new javax.swing.JButton();
        btperbarui = new javax.swing.JButton();
        bttampilkan = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        isi_harga = new javax.swing.JTextField();
        isi_idpelanggan = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 102, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ID");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Merk");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(38, 170, -1, -1));

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("QTY");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 170, -1, -1));

        isi_id.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        isi_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_idActionPerformed(evt);
            }
        });
        jPanel1.add(isi_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 127, 140, -1));

        isi_merk.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        isi_merk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_merkActionPerformed(evt);
            }
        });
        jPanel1.add(isi_merk, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 167, 140, -1));

        isi_qty.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        isi_qty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_qtyActionPerformed(evt);
            }
        });
        jPanel1.add(isi_qty, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 170, 130, -1));

        tabelmobil.setBackground(new java.awt.Color(233, 234, 206));
        tabelmobil.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Id", "Merk", "Warna", "Harga", "Id pelanggan"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tabelmobil);
        tabelmobil.getAccessibleContext().setAccessibleParent(tabelmobil);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 300, 550, 230));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Warna");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        isi_warna.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        isi_warna.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_warnaActionPerformed(evt);
            }
        });
        jPanel1.add(isi_warna, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 210, 130, -1));

        bttambah.setBackground(new java.awt.Color(153, 153, 153));
        bttambah.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bttambah.setText("Tambah");
        bttambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttambahActionPerformed(evt);
            }
        });
        jPanel1.add(bttambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 260, 100, 30));

        bthapus.setBackground(new java.awt.Color(153, 153, 153));
        bthapus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bthapus.setText("Hapus");
        bthapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bthapusActionPerformed(evt);
            }
        });
        jPanel1.add(bthapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 260, 80, 30));

        btperbarui.setBackground(new java.awt.Color(153, 153, 153));
        btperbarui.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btperbarui.setText("Update");
        btperbarui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btperbaruiActionPerformed(evt);
            }
        });
        jPanel1.add(btperbarui, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 260, -1, 30));

        bttampilkan.setBackground(new java.awt.Color(153, 153, 153));
        bttampilkan.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bttampilkan.setText("Tampilkan Data");
        bttampilkan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bttampilkanActionPerformed(evt);
            }
        });
        jPanel1.add(bttampilkan, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 260, 140, 30));

        jButton1.setBackground(new java.awt.Color(153, 153, 153));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton1.setText("Keluar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 540, 100, -1));

        jLabel1.setFont(new java.awt.Font("Dialog", 1, 24)); // NOI18N
        jLabel1.setText("Tambah Data Mobil");

        jLabel2.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel2.setText("Form Tambah Data ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(175, 175, 175)
                        .addComponent(jLabel1))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(223, 223, 223)
                        .addComponent(jLabel2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 610, 90));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Id pelanggan");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, -1, -1));

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Harga");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 130, -1, -1));

        isi_harga.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        isi_harga.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                isi_hargaActionPerformed(evt);
            }
        });
        jPanel1.add(isi_harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 120, 130, -1));

        isi_idpelanggan.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                isi_idpelangganPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        isi_idpelanggan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                isi_idpelangganMouseClicked(evt);
            }
        });
        jPanel1.add(isi_idpelanggan, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 220, 80, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 608, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 584, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void isi_merkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_merkActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_merkActionPerformed

    private void bttambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttambahActionPerformed
        Tambahdatamobil();
    }//GEN-LAST:event_bttambahActionPerformed

    private void btperbaruiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btperbaruiActionPerformed
        perbaruidata();
    }//GEN-LAST:event_btperbaruiActionPerformed

    private void bthapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bthapusActionPerformed
        Hapusdatamobil();
    }//GEN-LAST:event_bthapusActionPerformed

    private void bttampilkanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bttampilkanActionPerformed
        tampilkandata();
    }//GEN-LAST:event_bttampilkanActionPerformed

    private void isi_qtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_qtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_qtyActionPerformed

    private void isi_warnaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_warnaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_warnaActionPerformed

    private void isi_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_idActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        dispose();
        User lg = new User();
        lg.setVisible(true);
        lg.pack();
        lg.setLocationRelativeTo(null);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void isi_hargaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_isi_hargaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_isi_hargaActionPerformed

    private void isi_idpelangganMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_isi_idpelangganMouseClicked
         // TODO add your handling code here:
    }//GEN-LAST:event_isi_idpelangganMouseClicked

    private void isi_idpelangganPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_isi_idpelangganPopupMenuWillBecomeInvisible
        // TODO add your handling code here:
         String item = (String) isi_idpelanggan.getSelectedItem();
        String sql = "select * from listmobil where id = ?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, item);
            rs =pst.executeQuery();
        
           
            
            
          if(rs.next()){
               
          
                
          }
            
           
            
        } catch (Exception e) {
              JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_isi_idpelangganPopupMenuWillBecomeInvisible

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bthapus;
    private javax.swing.JButton btperbarui;
    private javax.swing.JButton bttambah;
    private javax.swing.JButton bttampilkan;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JTextField isi_harga;
    private javax.swing.JTextField isi_id;
    private javax.swing.JComboBox<String> isi_idpelanggan;
    private javax.swing.JTextField isi_merk;
    private javax.swing.JTextField isi_qty;
    private javax.swing.JTextField isi_warna;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabelmobil;
    // End of variables declaration//GEN-END:variables

    public void Hapusdatamobil(){
        try {
            String sql = "DELETE FROM `listmobil` WHERE id_Mobil="+isi_id.getText() ;
            java.sql.Connection con = (Connection) Koneksi.connect();
            java.sql.Statement stmt = con.createStatement();
            java.sql.PreparedStatement pstmt = con.prepareStatement(sql);
            pstmt.execute();
            JOptionPane.showMessageDialog(null, "Data berhasil dihapus!");
            tampilkandata();
            teks();
            
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }  
    }         
       
    }

